<?php

	$link = mysqli_connect("localhost","root","","CovidHelp");
	
	if (mysqli_connect_error()) {
		
		die("There was an error connecting to the database");
		
	}

	

?>